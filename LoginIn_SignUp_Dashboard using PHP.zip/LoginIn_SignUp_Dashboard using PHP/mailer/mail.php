          <?php
              require 'phpmailer/PHPMailerAutoload.php';
              if(isset($_POST['name']))
                  {
                    $to_id = $_POST['email'];
                    $message = "<h2><font color='blue'>Hello ".$_POST['name']." - Announcement from Navakishore Assignment</font><br> <br><br> <p><b><font color='green'>Thanks.</font></b></p>";
                    $subject = "From Navakishore Mailer - Portal";

                    $mail = new PHPMailer;

                    $mail->isSMTP();

                    $mail->Host = 'smtp.gmail.com';

                    $mail->Port = 587;

                    $mail->SMTPSecure = 'tls';

                    $mail->SMTPAuth = true;

                    $mail->Username = "dasarinavakishore@gmail.com";

                    $mail->Password = "Kishore@97";

                    $mail->setFrom($mail->Username, 'Navakishore Assignment');

                    $mail->addReplyTo($mail->Username, 'Navakishore Assignment');

                    $mail->addAddress($to_id);

                    $mail->Subject = $subject;

                    $mail->msgHTML($message);

                    if (!$mail->send()) {
                       
					   echo trim("NotOk");
                    } 
                    else {
                       echo trim('Ok');
                    }
               }
        ?>