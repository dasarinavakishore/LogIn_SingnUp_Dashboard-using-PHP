<?php
	function getSingleResultSet($con,$query){
		//echo $query;
		$result=$con->query($query);
		return $result->fetch_assoc();
	}
	function getCount($con,$query){
		//echo $query;
		$result=$con->query($query);
		return $result->num_rows;
	}
	function getMultiResultSet($con,$query){
		$result=$con->query($query);
		$array=[];
		while($record=$result->fetch_assoc()){
			array_push($array,$record);
		}
		return $array;
	}
	function urlSafeString($str)
	{
		$str = preg_replace("[^a-z0-9\040]","",str_replace("-"," ",$str));
		$str = preg_replace("[\040]i","-",trim($str));
		return $str;
	}
	function getReadableDate($date){
		$dateString=date("F", strtotime($date))." ".date("d", strtotime($date)).",".date("Y", strtotime($date))." ".date("h", strtotime($date)).":".date("i", strtotime($date))." ".date("A", strtotime($date));
		return $dateString;
	}
	function getReadableDateOnly($date){
		$dateString=date("F", strtotime($date))." ".date("d", strtotime($date)).",".date("Y", strtotime($date));
		return $dateString;
	}
	function custom_echo($x, $length)
	{
		  if(strlen($x)<=$length)
		  {
		    echo $x;
		  }
		  else
		  {
		    $y=substr($x,0,$length) . '...';
		    echo $y;
		  }
	}
?>