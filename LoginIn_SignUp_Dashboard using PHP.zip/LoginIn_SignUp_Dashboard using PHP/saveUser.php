<?php
//print_r(var_dump($_POST));
if(isset($_POST['name']))
{
	require("db.config.php");
$qdir="user_profile_pics/";
$query="insert into users(name,email,password,gender,phone,desig,role,created_on) values ('".$mysqlDB->real_escape_string($_POST['name'])."','".$mysqlDB->real_escape_string($_POST['email'])."','".$mysqlDB->real_escape_string($_POST['passwd'])."','".$mysqlDB->real_escape_string($_POST['gender'])."','".$mysqlDB->real_escape_string($_POST['phone'])."','".$mysqlDB->real_escape_string($_POST['desig'])."','".$mysqlDB->real_escape_string($_POST['role'])."','".date("Y-m-d h:i:s")."')";
if($mysqlDB->query($query))
{
	$id=$mysqlDB->insert_id;
	if(isset($_FILES['img'])==1){
		$img_path=upload_image($_FILES['img'],$qdir);
		$update_img="update users set image_path='".$img_path."' where id='".$id."'";
		if(!$mysqlDB->query($update_img)){
			$id=null;
		}
	}
	if($id==null){
		echo trim("NotOk");
	}
	else{
		echo trim("Ok");
	}
}
else{
	echo trim("Fail");
}
}
function upload_image($file,$dir){
	$fl=$file['name'];
	$filename=explode('.',$fl);
	$filename=str_replace(" ","_",$filename[0]);
	$extension = end(explode('.',$fl));
	$name = rand(1,99999).".".strtolower($extension); // avoid same file name collision
	if(move_uploaded_file( $file["tmp_name"], $dir.$name))
	{
		return $name;
	}
	else{
		return false;
	}
}
?>