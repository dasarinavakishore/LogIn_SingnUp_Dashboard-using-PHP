<?php session_start();
include("../db.config.php");
include("../commons.php");
if(isset($_SESSION['id'])){
	if(isset($_POST['id']))
	{
		 $query="SELECT image_path FROM users WHERE id='".$_POST['id']."'";
		 $result=$mysqlDB->query($query);
		 $record=$result->fetch_assoc();
		 $path="../user_profile_pics/".$record['image_path'];
		 $delete="DELETE FROM users WHERE id='".$_POST['id']."'";
		 $result=$mysqlDB->query($delete);
		 if($result)
		 {
			 if(file_exists($path))
			 {
					unlink($path); // delete file
			 }
			 echo "Ok";
			 
		 }
		 else{
			 echo "NotOk";
		 }
	   
	}
}
?>