<?php
session_start();
if (!empty($_POST) ) {
	if(isset($_SESSION['id'])){
		
		include("../db.config.php");
		include("../commons.php");
		$draw = $_POST["draw"];
		$orderBy="";
		if($_POST['orderBy']=="created_on"){
			$orderBy="order by created_on";
		}
		$orderType = $_POST['order'][0]['dir']; // ASC or DESC
		$start  = $_POST["start"];//first record indicator.
		$length = $_POST['length'];//Number of records
		/* END of POST variables */
		$json=array();
		if(!empty($_POST['search']['value'])){
			$programQuery="SELECT * FROM users WHERE (name LIKE '%".$_POST['search']['value']."%' OR email LIKE '%".$_POST['search']['value']."%' OR desig LIKE '%".$_POST['search']['value']."%') AND role='U' ".$orderBy." ".$orderType." LIMIT ".$start.",".$length;
			//echo $programQuery;
			$result=$mysqlDB->query($programQuery);
			$json=[]; $i=intval($start)+1;
			while($record=$result->fetch_assoc()){
				$id=$record['id'];
				array_push ( $json, array (
					"id" => $record['id'],
					"name" => $record['name'],
					"email" => $record['email'],
					"gender" => $record['gender'],
					"phone" => $record['phone'],
					"desig" => $record['desig'],
					"dateOn" => $record['created_on'],
					"status"=>$record['status'],
					"actions"=>"<button class='btn btn-info btn-sm edit-button'> Edit</button> <button class='btn btn-warning btn-sm delete-button'> Delete</button>"
				));
				$i++;
			}
            
			$recordsTotal = $result->num_rows;
			$recordsFiltered = getCount($mysqlDB,"SELECT id FROM users WHERE name LIKE '%".$_POST['search']['value']."%' OR email LIKE '%".$_POST['search']['value']."%' OR desig LIKE '%".$_POST['search']['value']."%' AND role='U'");
		}
		else{
			$query="SELECT * FROM users WHERE role='U' ".$orderBy." ".$orderType." LIMIT ".$start.",".$length;
			//echo $query;
			$result=$mysqlDB->query($query);
			$json=[];
			$i=intval($start)+1;
			while($record=$result->fetch_assoc()){
				$id=$record['id'];
				$gender="Female";
				if($record['gender']=="M"){
					$gender="Male";
				}
				array_push ( $json, array (
					"id" => $record['id'],
					"name" => $record['name'],
					"email" => $record['email'],
					"gender" => $gender,
					"phone" => $record['phone'],
					"desig" => $record['desig'],
					"dateOn" => $record['created_on'],
					"actions"=>"<button class='btn btn-info btn-sm edit-button'> Edit</button> <button class='btn btn-warning btn-sm delete-button'> Delete</button>",
					"status"=>$record['status']
				));
				$i++;
			}
            
			$recordsTotal = getCount($mysqlDB,$query);
			$recordsFiltered = getCount($mysqlDB,"SELECT id FROM users WHERE role='U'");
		}
		
		
		$response=array(
			"draw" => intval($draw),
			"recordsTotal" => $recordsTotal,
			"recordsFiltered" => $recordsFiltered,
			"data" => $json
		);
		echo json_encode($response);
		$mysqlDB->close();	
	}
}
?>

