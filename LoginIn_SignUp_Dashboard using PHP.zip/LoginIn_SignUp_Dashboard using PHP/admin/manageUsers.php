<link type="text/css" rel="stylesheet" href="../assets/datatables/datatables.min.css">
<table id="users" class="display table table-bordered" cellspacing="0" width="100%">
	<thead>
			<tr>
				<th>User ID</th>
				<th>Name</th>
				<th>Email</th>
				<th>Gender</th>
				<th>Phone</th>
				<th>Designation</th>
				<th>Registered On</th>
				<th>Actions</th>
			</tr>
		</thead>
</table>
<div class="modal fade" id="user-Modal" tabindex="-1" role="dialog" aria-labelledby="myModalLabel">
            <div class="modal-dialog" role="document" >
                <div class="modal-content">
                    <div class="modal-header">
                        <h4 class="modal-title" id="myModalLabel">Edit User</h4>
						<button type="button" class="close" data-dismiss="modal" aria-label="Close"><span aria-hidden="true">&times;</span></button>
                        
                    </div>
                    <div class="modal-body">
                        ...
                    </div>
                    <div class="modal-footer">
                        <button type="button" class="btn btn-default waves-effect" data-dismiss="modal">Close</button>
                    </div>
                </div>
            </div>
        </div>
		<p class="alert alert-success" id="msg"> Success Message.</p>
<script src="../assets/datatables/datatables.min.js"></script>
<script type="text/javascript">
	var table="";
    $(document).ready(function () {
        $(".preloader").hide();
        table=$('#users').DataTable({
            "columns": [
                {"data": "id"},
                {"data": "name"},
				{"data": "email"},
				{"data": "gender"},
				{"data": "phone"},
				{"data": "desig"},
				{"data": "dateOn"},
                {"data": "actions"},
				{"data":"status"},
            ],
			"order":[[6, "asc"]],
            "columnDefs": [
                {"width": "20%", "targets": 1},
				{"width": "20%", "targets": 2},
				{"width": "10%", "targets": 3},
                {"targets": [0,8], "visible": false, "searchable": false},
				{"targets": [1,2,3,4,5,7], "sortable": false},
				{"targets": [1,4,5,7], "searchable": false},
            ],
            "processing": true,
            "serverSide": true,
            "ajax": {
                url: 'loadUsers.php',
                type: 'POST',
                data: function (d) {
                    d.orderBy = "created_on";
                }
            },
			"fnRowCallback": function( nRow, aData, iDisplayIndex, iDisplayIndexFull ) { 
					  if ( aData.status == "Y" )
					  {
						$(nRow).find("td:first-child").append("<img src='../assets/images/active.png'/ class='float-right'>");
						console.log("yes");
					  }
			}
        }); 
    });
	
	$("#users").on("click", ".delete-button", function () {
        var row = $(this).closest('tr');
        var tData = table.row(row).data();
        var data = {id: tData.id};
		var conf=confirm("Are you sure want to delete?");
		if(conf)
		{
			ajaxHTML(data, "deleteUser.php", "POST").done(function (response) {
				console.log(response.trim());
				if (response.trim() == "Ok") {
					table.ajax.reload(null, false);
				} else {
					alert("Cannot delete user.");
				}
			});
		}
    });
	
	$("#users").on("click", ".edit-button", function () {
        var row = $(this).closest('tr');
        var tData = table.row(row).data();
        var data = {id: tData.id};
        ajaxHTML(data, "editUser.php", "POST").done(function (response) {
            if (response != "NotOK") {
                $("#user-Modal").modal("show");
                $("#user-Modal .modal-body").html(response);
            } else {
                alert("Cannot load User details.");
            }
        });
    });
	
	$('#user-Modal').on('hidden.bs.modal', function () {
		table.ajax.reload();
	});
</script>

