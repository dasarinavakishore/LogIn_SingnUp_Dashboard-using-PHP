<?php
session_start();
if(isset($_SESSION['id'])){
	?>
	<!DOCTYPE html>
 <html>
    <head>

	 <meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
     <meta charset="utf-8" />
     <meta http-equiv="X-UA-Compatible" content="IE=edge" />
     <title>PHP-Login</title>
     <meta name="description" content="" />
     <meta name="viewport" content="width=device-width, initial-scale=1" />
	 <link href="../assets/css/bootstrap.min.css" type="text/css" rel="stylesheet">
	 <link href="../assets/css/style.css" type="text/css" rel="stylesheet">
	 <style>
		body{
			background: whitesmoke;
		}
		.container-fluid{
			min-height:50vh;
			background: #fff;
			width: 100%;
			max-width:100%;
			margin-top:20px;
		}
	 </style>
	</head>
	<body>
		<nav id="nav-header" class="navbar navbar-expand-lg navbar-light bg-light">
		  <a class="navbar-brand" href="#"></a>
		  <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
			<span class="navbar-toggler-icon"></span>
		  </button>

		  <div class="collapse navbar-collapse" id="navbarSupportedContent">
			<ul class="navbar-nav mr-auto">
			  
			</ul>
			<form class="my-2 my-lg-0">
				<ul class="navbar-nav mr-auto">
				  <li class="nav-item active">
					<a class="nav-link"><?php echo $_SESSION['name'];?></a>
				  </li>
				  <li class="nav-item">
					<a class="nav-link"><i>(Logged in as ADMIN)</i></a>
				  </li>
				  <li class="nav-item active">
					<a class="nav-link" href="../logout.php">Logout</a>
				  </li>
				</ul>
			</form>
		  </div>
		</nav>
		<div class="container-fluid">
			<div class="row">
			  <div class="col-2">
				<div class="nav flex-column nav-pills" id="menu" role="tablist" aria-orientation="vertical">
				  <a class="nav-link" href="#welcome" role="tab">Home</a>
				  <a class="nav-link" href="#editProfile">Profile</a>
				  <a class="nav-link" href="#manageUsers">Users</a>
				</div>
			  </div>
			  <div class="col-10">
				<div class="tab-content" id="v-pills-tabContent">
				  <div class="tab-pane fade show active" id="page-load">
					
				  </div>
				</div>
			  </div>
			</div>
		</div>
	</body>
	<p class="alert alert-success" id="msg"> </p>
	<script src="../assets/js/jquery.min.js"></script>
	<script src="../assets/js/bootstrap.min.js"></script>
	<script src="../assets/js/commons.js"></script>
	<script src="../assets/js/dashboard-commons.js"></script>
	<script>
	
	</script>
 </html>
	<?php
}

?>