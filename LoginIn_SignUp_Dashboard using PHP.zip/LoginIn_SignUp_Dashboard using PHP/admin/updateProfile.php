<?php
if(isset($_POST['id']))
{
	require("../db.config.php");
$qdir="../user_profile_pics/";
$query="SELECT * FROM users WHERE id='".$_POST['id']."'";
		 $result=$mysqlDB->query($query);
		 $record=$result->fetch_assoc();
		 
$query="update users set name='".$mysqlDB->real_escape_string($_POST['name'])."', email='".$mysqlDB->real_escape_string($_POST['email'])."',password='".$mysqlDB->real_escape_string($_POST['passwd'])."',gender='".$mysqlDB->real_escape_string($_POST['gender'])."',phone='".$mysqlDB->real_escape_string($_POST['phone'])."',desig='".$mysqlDB->real_escape_string($_POST['desig'])."',updated_on='".date("Y-m-d h:i:s")."' where id='".$_POST['id']."'";
//echo $query;
if($mysqlDB->query($query))
{
	$id=$_POST['id'];
	$returnFilename=$record['image_path'];
	if(isset($_FILES['img'])==1){
		$fl=$_FILES['img']['name'];
		$filename=explode('.',$fl);
		$filename=str_replace(" ","_",$filename[0]);
		$extension = end(explode('.',$fl));
		$name = rand(1,99999).".".strtolower($extension); // avoid same file name collision
		if(file_exists($qdir.$returnFilename) && !empty($record['image_path'])){
			unlink($qdir.$record['image_path']);
		}
		if(move_uploaded_file( $_FILES['img']["tmp_name"], $qdir.$name))
		{
			$img_path=$name;
			$update_img="update users set image_path='".$img_path."' where id='".$id."'";
			if(!$mysqlDB->query($update_img)){
				$id=null;
			}
		}
	}
	if($id==null){
		echo trim("NotOk");
	}
	else{
		echo trim("Ok");
	}
}
else{
	echo trim("Fail");
}
}
?>