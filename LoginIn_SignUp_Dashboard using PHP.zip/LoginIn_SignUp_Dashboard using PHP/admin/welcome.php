<?php
session_start();
?>
<h3>Welcome <?php echo strtoupper($_SESSION['name']);?>!!!</h2>
					<p>
						You can update your profile.
					</p>
					<p>
						You can manage registered users.
					</p>	
<?php

?>					