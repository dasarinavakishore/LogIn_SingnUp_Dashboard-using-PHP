<?php
if(isset($_POST['email'])){
	include("db.config.php");
	$query="select email from users where email='".$_POST['email']."'";
	$num=$mysqlDB->query($query);
	if($num->num_rows>0){
		echo trim("true");
	}
	else{
		echo trim("false");
	}
}

?>