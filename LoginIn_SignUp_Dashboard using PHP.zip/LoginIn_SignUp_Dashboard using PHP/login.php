<!DOCTYPE html>
 <html>
      <!-- Login page -->
     
    <head>
	 <meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
     <meta charset="utf-8" />
     <meta http-equiv="X-UA-Compatible" content="IE=edge" />
     <title>PHP-Login</title>
     <meta name="description" content="" />
     <meta name="viewport" content="width=device-width, initial-scale=1" />
	 <link href="assets/css/bootstrap.min.css" type="text/css" rel="stylesheet">
	 <link href="assets/css/style.css" type="text/css" rel="stylesheet">
	 <style>
		
	 </style>
	</head>
	<body style="background-color: #ff9c32 ;">
		<?php include("index-header.php"); ?>
		<div class="container" style="width:30%">
            <h2>Login:</h2>
			<form id="form" name="reg">
			<div class="col-md-12">
				<div class="form-group">
					<label class="float-label" for="email2">Email:-</label>
					<input type="email" class="form-control" required id="email2" title="This field is required">
					<span class="help-block">  </span>
				</div>
				<div class="form-group">
					<label class="float-label" for="passwd">Password:-</label>
					<input type="password" class="form-control" id="passwd" title="This field is required">
					<span class="help-block">  </span>
				</div>
				<div class="form-group text-center">
					<button type="button" id="register" class="btn btn-info btn-sm col-sm-4">Login</button>
				</div>
			</div>
			</form>	
		</div>
	</body>
	<p class="alert alert-success" id="msg"> </p>
	<script src="assets/js/jquery.min.js"></script>
	<script src="assets/js/bootstrap.min.js"></script>
	<script src="assets/js/commons.js"></script>
	<script>
		
	$("#register").on("click",function(){
		var btn=$(this);
		var email=$("#email2").val().trim();
		var passwd=$("#passwd").val().trim();
		if(!EmailOnly("email2")){
			return false;
		}
		else{
			hideMsg($("#email2"));
		}
		var formData=new FormData();
		formData.append("email",email); formData.append("passwd",passwd);
		btn.attr("disabled","disabled");
		btn.html("Please wait");
		$.ajax({
			method: 'POST',
			type: "POST",
			url: "userLogin.php",
			data: formData,
			cache: false,
			contentType: false,
			processData: false,
			success: function(resp){
				resp=jQuery.parseJSON(resp);
				if(resp.status=="true"){
					if(resp.role=="A"){
						successDialog($("#msg"),"Success!! You have Logged in.... please wait.");
						location.href="admin/home.php";
					}
					else if(resp.role=="U"){
						successDialog($("#msg"),"Success!! You have Logged in.... please wait.");
						location.href="user/home.php";
					}
				}
				else if(resp.status=="false"){
					errorDialog($("#msg"),"Invalid Credentials!! Username/Password doesn't match.");
				}
				$("#msg").fadeTo(5000, 500).slideUp(500, function(){
					$("#msg").slideUp(500);
				});
				btn.removeAttr("disabled");
				btn.html("Login");
			}
		});
	});
	</script>
</html>	