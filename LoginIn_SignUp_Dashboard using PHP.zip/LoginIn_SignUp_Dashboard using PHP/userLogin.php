<?php
if(isset($_POST['email'])){
	include("db.config.php");
	$query="select name,id,role from users where email='".$_POST['email']."' and password='".$_POST['passwd']."'";
	$num=$mysqlDB->query($query);
	if($num->num_rows>0){
		$resultSet=$num->fetch_assoc();
		session_start();
		$_SESSION['name']=$resultSet['name'];
		$_SESSION['id']=$resultSet['id'];
		echo json_encode(array("status"=>"true","role"=>$resultSet['role']));
	}
	else{
		echo json_encode(array("status"=>"false"));
	}
}

?>