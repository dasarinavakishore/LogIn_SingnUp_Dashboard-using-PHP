<?php
	$mysqlDB = new mysqli("localhost","root","Navakishore","Navakishore");
	date_default_timezone_set("Asia/Kolkata");
	if($mysqlDB->connect_error){
		die("MySql Connection failed: " . $mysqlDB->connect_error);
	}
	
?>