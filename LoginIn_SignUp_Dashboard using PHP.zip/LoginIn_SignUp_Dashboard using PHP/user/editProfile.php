<?php session_start();
include("../db.config.php");
include("../commons.php");
if(isset($_SESSION['id'])){
		$query="SELECT * FROM users WHERE id='".$_SESSION['id']."'";
		 $result=$mysqlDB->query($query);
		 $record=$result->fetch_assoc();
?>
	 <link href="../assets/css/bootstrap.min.css" type="text/css" rel="stylesheet">
		<div class="container" style="width:60%">
			<form id="form" name="reg">
			<div class="col-md-12">
				<div class="form-group">
					<label class="float-label" for="name">Name</label>
					<input type="text" class="form-control" id="name" title="This field is required" value="<?php echo $record['name'];?>">
					<span class="help-block">  </span>
				</div>
				<div class="form-group">
					<label class="float-label" for="email">Email</label>
					<input type="email" class="form-control" required id="email" title="This field is required" value="<?php echo $record['email'];?>">
					<span class="help-block">  </span>
				</div>
				<div class="form-group">
					<label class="float-label" for="passwd">Password</label>
					<input type="password" class="form-control" id="passwd" title="This field is required" value="<?php echo $record['password'];?>">
					<span class="help-block">  </span>
				</div>
				<div class="form-group">
					<label class="float-label" for="image">Profile pic</label>
					<input type="file" class="form-control" id="image" title="This field is required">
					<span class="help-block"> Help </span>
					<?php
						$thumb="";
						if(file_exists("../user_profile_pics/".$record['image_path']))
						{
							$thumb="../user_profile_pics/".$record['image_path'];
						}
						?>
						<div class="col-md-3"><img class="img-fluid" src="<?=$thumb?>" id="thumbnail"></div>
				</div>
				<div class="form-group">
					<label class="float-label" for="gender">Gender</label>
					<select class="form-control" id="gender">
						<option <?php if($record['gender']=="F") echo "selected";?> value="F">Female</option>
						<option <?php if($record['gender']=="M") echo "selected";?> value="M">Male</option>
					</select>
					<span class="help-block"> Help </span>
				</div>
				<div class="form-group">
					<label class="float-label" for="phone">Phone</label>
					<input type="text" class="form-control" onKeyPress="return NumbersOnly(this, event)" id="phone" title="This field is required" value="<?php echo $record['phone'];?>">
					<span class="help-block"> Help </span>
				</div>
				<div class="form-group">
					<label class="float-label" for="desig">Designation</label>
					<input type="text" class="form-control" id="desig" title="This field is required" value="<?php echo $record['desig'];?>">
					<span class="help-block"> Help </span>
				</div>
				<div class="form-group text-center">
					<button type="button" id="register" class="btn btn-primary btn-sm">Update Profile</button>
				</div>
			</div>
			</form>	
		</div>
	
	<script src="../assets/js/jquery.min.js"></script>
	<script src="../assets/js/bootstrap.min.js"></script>
	<script src="../assets/js/commons.js"></script>
	<script>
		
	$("#register").on("click",function(){
		var btn=$(this);
		var id="<?php echo $_SESSION['id'];?>";
		var img=$("#image")[0].files[0];
		var name=$("#name").val().trim();
		var email=$("#email").val().trim();
		var passwd=$("#passwd").val().trim();
		var phone=$("#phone").val().trim();
		var desig=$("#desig").val().trim();
		if(!textValid(name,4,25)){
			errorMsg($("#name"),"Name should be in between 4 to 25 characters.");
			return false;
		}
		else{
			hideMsg($("#name"));
		}
		if(!textValid(email,8,50))
		{
			errorMsg($("#email"),"Email should be in between 8 to 50 characters.");
			return false;
		}
		else if(!EmailOnly("email")){
			return false;
		}
		else{
			hideMsg($("#email"));
		}
		if($("#image").val()!=undefined && $("#image").val()!=""){
			if(!checkIfImage(img.type)){
				errorMsg($("#image"),"Please upload only png/jpg/jpeg image.");
				return false;
			}
			if(!checkImageSize(img)){
				errorMsg($("#image"),"Image size is more than 750kb. Please upload image less than 700kb.");
				return false;
			}
			hideMsg($("#image"));
		}
		/*else{
			errorMsg($("#image"),"Please upload profile photo.");
		}*/
		if(!textValid(passwd,5,30)){
			errorMsg($("#passwd"),"Pwd length in between 5 to 30 char's & use symbols '@,$,#,&,*,etc..'");
			return false;
		}
		else{
			hideMsg($("#passwd"));
		}
		if(!textValid(phone,10,10)){
			errorMsg($("#phone"),"Phone number should contain 10 digits.");
			return false;
		}
		else{
			hideMsg($("#phone"));
		}
		if(!textValid(desig,3,25)){
			errorMsg($("#desig"),"Designation should be in between 3 to 25 characters.");
			return false;
		}
		else{
			hideMsg($("#desig"));
		}
		/*if(role.find("option:selected").index>0){
			errorMsg(role,"Please choose a role.");
			return false;
		}
		else{
			hideMsg(role);
		}*/

		var formData=new FormData();
		formData.append("id",id);
		formData.append("name",name); formData.append("email",email); formData.append("passwd",passwd); formData.append("img",img); formData.append("gender",$("#gender").val()); formData.append("phone",phone); formData.append("desig",desig);
		btn.attr("disabled","disabled");
		btn.html("Please wait");
		$.ajax({
			method: 'POST',
			type: "POST",
			url: "updateProfile.php",
			data: formData,
			cache: false,
			contentType: false,
			processData: false,
			success: function(resp){
				if(resp.trim()=="Ok"){
					successDialog($("#msg"),"Success!! Profile successfully updated.");
					if(document.getElementById('image').value!=""){
						previewFile();
					}
				}
				else if(resp.trim()=="Fail"){
					errorDialog($("#msg"),"Something went wrong please try again");
				}
				$("#msg").fadeTo(5000, 500).slideUp(500, function(){
					$("#msg").slideUp(500);
				});
				btn.removeAttr("disabled");
				btn.html("Update Profile");
			}
		});
	});
	
	function previewFile() {
	  var preview = document.getElementById('thumbnail');
	  var file    = document.getElementById('image').files[0];
	  var reader  = new FileReader();

	  reader.onloadend = function () {
		preview.src = reader.result;
	  }

	  if (file) {
		reader.readAsDataURL(file);
	  } else {
		preview.src = "";
	  }
	}
	</script>
<?php
	}
?>