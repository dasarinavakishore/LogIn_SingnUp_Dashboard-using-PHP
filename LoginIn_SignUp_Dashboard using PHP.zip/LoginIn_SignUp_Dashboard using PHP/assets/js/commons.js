function EmailOnly(id)
	{
	  var val=document.getElementById(id).value;
	  var m = val;
	  var n = val;
	  var cnt=0,spc=0,dot=0,sngCode=0;
	  for(var i=1;i<=m.length;i++)
	  {
		 if(m.charAt(i)=="@")  cnt++; //should be 1
		 if(m.charAt(i)==" ")  spc++; // should be 0
		 if(m.charAt(i)==".")  dot++; // should be atleast 1
		 if(m.charAt(i)=="'")  sngCode++;//should be 0
	 }
	  lnm=m.length;
	  if(cnt==0||cnt>1||spc!=0||dot==0||sngCode>1)
	  {
		errorMsg($("#"+id),"Invalid mail address.Mail id should have an @,nospaces and a '.' ");
		document.getElementById(id).focus();
		return false;
	  } 
	 var ldot=m.lastIndexOf(".");
	 var lat=m.lastIndexOf("@"); //alert(lat);
	 var ldotat=ldot-lat;
	 //alert(ldotat);
	 //alert("last dot:"+(ldot+1));
	 com=lnm-(ldot+1);
	 if(ldotat<=1||com<=1||m.indexOf(".")==0||m.indexOf("@")==0)
	 {
		 errorMsg($("#"+id),"Invalid mail address");
		 document.getElementById(id).focus();
		 return false;
	}
	return true;
}

function checkIfImage(type){
		if(type=="image/png" || type=="image/jpg" || type=="image/jpeg"){
			return true;
		}
		return false;
	}
	function checkImageSize(image){
		var size = image.size;
		if((Math.round(size))<=2000000) //size is 2MB
		{
			return true;
		}
		return false;
	}
	function textValid(input,min,max){
		if(input.length<min || input.length>max){
			return false;
		}
		return true;
	}
	function hideMsg($element){
		$element.parent().find(".help-block").hide();
	}
	function successMsg($element,message){
		$element.parent().find(".help-block").show();
		$element.parent().find(".help-block").addClass("text-success").removeClass("text-danger");
		$element.parent().find(".help-block").html(message);
	}
	function errorMsg($element,message){
		$element.parent().find(".help-block").show();
		$element.parent().find(".help-block").addClass("text-danger").removeClass("text-success");
		$element.parent().find(".help-block").html(message);
	}
	function successDialog($element,message){
		$element.show();
		$element.addClass("alert-success").removeClass("alert-danger");
		$element.html(message);
	}
	function errorDialog($element,message){
		$element.show();
		$element.addClass("alert-danger").removeClass("alert-success");
		$element.html(message);
	}
	$("#email").on("blur",function(){
		var val=$("#email").val();
		$.ajax({
			type: "POST",
			url: "checkEmailExists.php",
			data: {email:val},
			success: function(resp){
				if(resp.trim()=="true"){
					errorMsg($("#email"),"Email id already exists. please enter another email id.");
					$("#email")[0].focus();
					$("#register").attr("disabled","disabled");
				}
				else{
					hideMsg($("#email"));
					$("#register").removeAttr("disabled");
				}
			}
		});
	});
function ajaxJSON(formdata,urlpath,method) {
	var params=JSON.stringify(formdata);
    return $.ajax({
        cache:      false,
        url:        urlpath,
        dataType:   "json",
        type:       method,
        data:       {postdata:params}
    });             
}
function ajaxHTML(data,urlpath,method) {
    return $.ajax({
        cache:      false,
        url:        urlpath,
        type:       method,
        data:       data
    });             
}
function NumbersOnly(MyField, e, dec)
	{
	
		var key;
		var keychar;
		
		if (window.event)
		{
	         key = window.event.keyCode;//GET ASCII VALUE
			 //alert(key);
		}
		else if (e)
		{
		   key = e.which;
		   //alert(2); 
		 }
		else
		   return true;
		keychar = String.fromCharCode(key);
		
		if ((key==null) || (key==0) || (key==8) ||
			(key==9) || (key==13) || (key==27) )
		   return true;
		
		else if ((("0123456789").indexOf(keychar) > -1))
		   return true;
		
		else if (dec && (keychar == "."))
		   {
		   MyField.form.elements[dec].focus();
		   return false;
		   }
		else
		   return false;
	}