function loadSingleModulePage($wrapper,url,paramId){
	 		$wrapper.load(url+".php",{url:paramId}, function( response, status, xhr ) {
				  if ( status == "error" ) {
					    var msg = "Sorry the page you are looking for is not found with us :";
					    $wrapper.html( msg + xhr.status + " " + xhr.statusText );
					}
					else{
						$("title").html(url+" - Manaswini Assignment");
					}
					$(".nav-link").removeClass("active");
						$(".nav-link[href='#"+url+"']").addClass("active");
			});
	 	}
$("#menu").on("click",".nav-link",function(){
	 		//$(".preloader").slideDown(500);
			var currentURL = $(this).attr("href");
		    var url=currentURL.split("#");
	 		loadSingleModulePage($("#page-load"),url[1],"");
			
	 	});
$(window).on("load",function() {
		     var currentURL = window.location.href;
		     var index = currentURL.indexOf("#");
		     if(index > -1) {
				 var url=currentURL.split("#");
		         loadSingleModulePage($("#page-load"),url[1],"");
			 }
		     else{
		     	loadSingleModulePage($("#page-load"),"welcome","");
		     }
		});		