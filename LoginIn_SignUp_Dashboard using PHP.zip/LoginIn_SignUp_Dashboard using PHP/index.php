<!DOCTYPE html>
 <html>
    <head>

	 <meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
     <meta charset="utf-8" />
     <meta http-equiv="X-UA-Compatible" content="IE=edge" />
     <title>PHP-Register</title>
     <meta name="description" content="" />
     <meta name="viewport" content="width=device-width, initial-scale=1" />
	 <link href="assets/css/bootstrap.min.css" type="text/css" rel="stylesheet">
	 <link href="assets/css/style.css" type="text/css" rel="stylesheet">
	 <style>
		.form-control{
			padding: .2rem .6rem !important;
			line-height: 1em !important;
		}
		.form-group {
			margin-bottom: 0.6rem !important;
		}
		label {
			margin-bottom: .1rem !important;
		}
		select.form-control:not([size]):not([multiple]) {
			height: calc(1.9rem + 2px);
		}
		#msg{
			position: fixed;
			top: 1em;
			width: 30%;
			margin-left: auto;
			margin-right: auto;
			left: 0;
			right: 0;
			display:none;
		}
	 </style>
	</head>
	<body style="background-color: #ff9c32 ;">
		<?php include("index-header.php"); ?>
		<div class="container" style="width:30%">
            
            <h2>Create an account</h2>
            
			<form id="form" name="reg">
			<div class="col-md-12">
				<div class="form-group">
					<label class="float-label" for="name">Name:-</label>
					<input type="text" class="form-control" id="name" title="This field is required">
					<span class="help-block">  </span>
				</div>
				<div class="form-group">
					<label class="float-label" for="email">Email:-</label>
					<input type="email" class="form-control" required id="email" title="This field is required">
					<span class="help-block">  </span>
				</div>
				<div class="form-group">
					<label class="float-label" for="passwd">Password:-</label>
					<input type="password" class="form-control" id="passwd" title="This field is required">
					<span class="help-block">  </span>
				</div>
				<div class="form-group">
					<label class="float-label" for="image">Profile Img:-</label>
					<input type="file" class="form-control" id="image" title="This field is required">
					<span class="help-block"> Help </span>
				</div>
				<div class="form-group">
					<label class="float-label" for="gender">Gender:-</label>
					<select class="form-control" id="gender">
						<option value="F">Female</option>
						<option value="M">Male</option>
					</select>
					<span class="help-block"> Help </span>
				</div>
				<div class="form-group">
					<label class="float-label" for="phone">Phone:-</label>
					<input type="text" class="form-control" onKeyPress="return NumbersOnly(this, event)" id="phone" title="This field is required">
					<span class="help-block"> Help </span>
				</div>
				<div class="form-group">
					<label class="float-label" for="desig">Designation:-</label>
					<input type="text" class="form-control" id="desig" title="This field is required">
					<span class="help-block"> Help </span>
				</div>
				<div class="form-group">
					<label class="float-label" for="role">Role:-</label>
					<select class="form-control" id="role">
						<option value="-1">[--Choose Role--]</option>
						<option value="A">Admin</option>
						<option value="U">User</option>
					</select>
					<span class="help-block"> Help </span>
				</div>
				<div class="form-group text-center">
					<button type="button" id="register" class="btn btn-success btn-sm">Register</button>
				</div>
			</div>
			</form>	
		</div>
	</body>
	<p class="alert alert-success" id="msg"> Success Message.</p>
	<script src="assets/js/jquery.min.js"></script>
	<script src="assets/js/bootstrap.min.js"></script>
	<script src="assets/js/commons.js"></script>
	<script>
		
	$("#register").on("click",function(){
		var btn=$(this);
		var img=$("#image")[0].files[0];
		var name=$("#name").val().trim();
		var email=$("#email").val().trim();
		var passwd=$("#passwd").val().trim();
		var phone=$("#phone").val().trim();
		var desig=$("#desig").val().trim();
		var role=$("#role");
		if(!textValid(name,4,25)){
			errorMsg($("#name"),"Name should be in between 4 to 25 characters.");
			return false;
		}
		else{
			hideMsg($("#name"));
		}
		if(!textValid(email,8,50))
		{
			errorMsg($("#email"),"Email should be in between 8 to 50 characters.");
			return false;
		}
		else if(!EmailOnly("email")){
			return false;
		}
		else{
			hideMsg($("#email"));
		}
		if($("#image").val()!=undefined && $("#image").val()!=""){
			if(!checkIfImage(img.type)){
				errorMsg($("#image"),"Please upload only png/jpg/jpeg image.");
				return false;
			}
			if(!checkImageSize(img)){
				errorMsg($("#image"),"Image size is more than 750KB. Please upload image less than 700KB.");
				return false;
			}
			hideMsg($("#image"));
		}
		else{
			errorMsg($("#image"),"Please upload profile photo.");
		}
		if(!textValid(passwd,5,30)){
			errorMsg($("#passwd"),"Pwd length in between 5 to 30 char's & use symbols '@,$,#,&,*,etc..'");
			return false;
		}
		else{
			hideMsg($("#passwd"));
		}
		if(!textValid(phone,10,10)){
			errorMsg($("#phone"),"Phone number should contain 10 digits.");
			return false;
		}
		else{
			hideMsg($("#phone"));
		}
		if(!textValid(desig,3,30)){
			errorMsg($("#desig"),"Designation should be in between 3 to 30 characters.");
			return false;
		}
		else{
			hideMsg($("#desig"));
		}
		if(role.find("option:selected").index>0){
			errorMsg(role,"Please choose a role.");
			return false;
		}
		else{
			hideMsg(role);
		}

		var formData=new FormData();
		formData.append("name",name); formData.append("email",email); formData.append("passwd",passwd); formData.append("img",img); formData.append("gender",$("#gender").val()); formData.append("phone",phone); formData.append("desig",desig); formData.append("role",role.val());
		role=role.find("option:selected").text();
		/*var dt={testId:testId, queText:question, quesImg:question_img, opt1:option1, optImg1:opt1_img, opt2:option2, optImg2:opt2_img, opt3:option3, optImg3:opt3_img, opt4:option4, optImg4:opt4_img, correctAnswer:correct};*/
		btn.attr("disabled","disabled");
		btn.html("Please wait");
		$.ajax({
			method: 'POST',
			type: "POST",
			url: "saveUser.php",
			data: formData,
			cache: false,
			contentType: false,
			processData: false,
			success: function(resp){
				if(resp.trim()=="Ok"){
					$("#msg").show();
					$("#msg").html("Success!! You have successfully registered.");
					document.forms['reg'].reset();
					successDialog($("#msg"),"Congrats!! You have successfully registered as "+role+".");
				}
				else if(resp.trim()=="Fail"){
					errorDialog($("#msg"),"Something went wrong please try again");
				}
				$("#msg").fadeTo(5000, 500).slideUp(500, function(){
					$("#msg").slideUp(500);
				});
				btn.removeAttr("disabled");
				btn.html("Register");
			}
		});
	});
	</script>
</html>	